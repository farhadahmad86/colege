@extends('extend_index')
@section('styles_get')
    <style>
        .action_td .dropdown .dropdown-toggle::after {
            content: unset !important;
        }
    </style>
@stop
@section('content')

    <div class="row">
        <div class="container-fluid search-filter form-group form_manage">
            <div class="form_header">
                <!-- form header start -->
                <div class="clearfix">
                    <div class="pull-left">
                        <h4 class="text-white get-heading-text file_name">Student Attendance List</h4>
                    </div>
                    <div class="list_btn list_mul">
                        <div class="srch_box_opn_icon">
                            <i class="fa fa-search"></i>
                        </div>
                    </div><!-- list btn -->
                </div>
            </div><!-- form header close -->
            <div class="search_form m-0 p-0">
                <form class="highlight prnt_lst_frm"
                    action="{{ route('student_attendance_list') . (isset($restore_list) && $restore_list == 1 ? '?restore_list=1' : '') }}"
                    name="form1" id="form1" method="post">
                    <div class="row">
                        @csrf
                        <div class="form-group col-lg-2 col-md-3 col-sm-12 col-xs-12">
                            <select tabindex="1" autofocus name="search" class="inputs_up form-control required"
                                id="search" autofocus data-rule-required="true" data-msg-required="Please Enter Class">
                                <option value="">Select Class</option>

                                @foreach ($class_title as $class)
                                    <option  value="{{ $class->class_id }}" {{ $class->class_id == $search ? 'selected' : ''}}> 
                                        {{ $class->class_name }}
                                    </option>
                                @endforeach

                            </select>
                        </div>
                        <div class="form-group col-lg-2 col-md-3 col-sm-12 col-xs-12">
                            <div class="input_bx">
                                <!-- start input box -->
                                <input tabindex="2" type="text" name="date" id="date"
                                    class="inputs_up form-control datepicker1" autocomplete="off" <?php if(isset($search_by_date)){?>
                                    value="{{ $search_by_date }}" <?php } ?> placeholder="Date ......" />
                                <span id="demo1" class="validate_sign" style="float: right !important">
                                </span>
                            </div>
                        </div>
                        <!-- left column ends here -->
                        <div class="col-lg-8 col-md-9 col-sm-12 col-xs-12 text-right form_controls">
                            @include('include.clear_search_button')
                            <!-- Call add button component -->
                            <x-add-button tabindex="9" href="{{ route('mark_student_attendance') }}" />

                            @include('include/print_button')
                            <span id="demo1" class="validate_sign" style="float: right !important"> </span>
                        </div>
                    </div><!-- end row -->
                </form>
                {{-- <form name="edit" id="edit" action="{{ route('edit_classes') }}" method="post">
                    @csrf
                    <input name="title" id="title" type="hidden">
                    <input name="class_degree_id" id="class_degree_id" type="hidden">
                    <input name="program_id" id="program_id" type="hidden">
                    <input name="class_id" id="class_id" type="hidden">
                    <input name="session_id" id="session_id" type="hidden">
                    <input name="class_demand" id="class_demand" type="hidden">
                    <input name="class_type" id="class_type" type="hidden">
                    <input name="class_attendance" id="class_attendance" type="hidden">
                </form> --}}
                <form name="edit" id="edit" action="{{ route('edit_student_attendance') }}" method="post">
                    @csrf
                    <input name="title" id="title" type="hidden">
                    <input name="class_degree_id" id="class_degree_id" type="hidden">
                    <input name="program_id" id="program_id" type="hidden">
                    <input name="class_id" id="class_id" type="hidden">
                    <input name="session_id" id="session_id" type="hidden">
                    <input name="class_demand" id="class_demand" type="hidden">
                    <input name="class_type" id="class_type" type="hidden">
                    <input name="class_attendance" id="class_attendance" type="hidden">
                </form>
                <form name="delete" id="delete" action="{{ route('delete_classes') }}" method="post">
                    @csrf
                    <input name="class_id" id="class_id" type="hidden">
                </form>
            </div>

            <div class="table-responsive" id="printTable">
                <table class="table table-bordered table-sm" id="fixTable">

                    <thead>
                        <tr>
                            <th scope="col" class="tbl_srl_4">
                                ID
                            </th>
                            <th scope="col" class="tbl_txt_20">
                                Class Name
                            </th>
                            <th scope="col" class="tbl_txt_8">
                                Section Name
                            </th>
                            <th scope="col" class="tbl_txt_35">
                                View List
                            </th>
                            <th scope="col" class="tbl_txt_10">
                                Attendance</th>
                            <th scope="col" class="tbl_txt_10">
                                Date</th>
                            <th scope="col" class="tbl_txt_10">
                                Created By</th>
                            {{-- <th scope="col" class="tbl_txt_8">
                                Created By
                            </th> --}}
                            {{-- <th scope="col" class="hide_column tbl_srl_6">
                                Enable
                            </th> --}}
                        </tr>
                    </thead>

                    <tbody>
                        @php
                            $segmentSr = !empty(app('request')->input('segmentSr')) ? app('request')->input('segmentSr') : '';
                            $segmentPg = !empty(app('request')->input('page')) ? app('request')->input('page') : '';
                            $sr = !empty($segmentSr) ? $segmentSr * $segmentPg - $segmentSr + 1 : 1;
                            $countSeg = !empty($segmentSr) ? $segmentSr : 0;
                        @endphp
                        @forelse($datas as $data)

                            <tr data-std_att_id="{{ $data->std_att_id }}" data-class_id="{{ $data->class_id }}"
                                data-student_id="{{ $data->std_att_student_id }}">
                                <th scope="row">
                                    {{ $sr }}
                                </th>
                                <td class="edit ">
                                    {{ $data->class_name }}
                                </td>
                                <td class="edit ">
                                    {{ $data->cs_name }}
                                </td>
                                {{-- <td class="view" data-class_id="{{ $data->class_id }}"
                                    data-cs_id="{{ $data->cs_id }}"
                                    data-std_att_created_at="{{ $data->std_att_created_at }}">
                                    View List
                                </td> --}}
                                {{-- @php
                                    $presentCount = 0;
                                    $absentCount = 0;
                                    $leaveCount = 0;
                                @endphp --}}
                                @php
                                // Get all student IDs from the attendance data
                                $studentIds = collect(json_decode($data->std_attendance, true))->pluck('student_id');
                            
                                // Fetch all students using the student IDs
                                $students = App\Models\College\Student::whereIn('id', $studentIds)->get();
                            
                                // Create a lookup array to easily access student details inside the loop
                                $studentLookup = [];
                                foreach ($students as $student) {
                                    $studentLookup[$student->id] = $student;
                                }
                            @endphp
                            <td>
                            @foreach (json_decode($data->std_attendance, true) as $attendance)
                                @php
                                    $student = $studentLookup[$attendance['student_id']] ?? null;
                                @endphp
                                 @if ($student)
                                 {{ $student->full_name }} ({{ $attendance['is_present'] }}),  
                            @else
                                Student ID: {{ $attendance['student_id'] }} - Student not found - Attendance: {{ $attendance['is_present'] }}
                            @endif
                            
                             @endforeach
                                
                                   
                                </td>
                           
                                {{-- <td class="edit" data-toggle="tooltip"
                                    title="Present: {{ $presentCount }}, Absent: {{ $absentCount }}, Leave: {{ $leaveCount }}">
                                    P-{{ $presentCount }}
                                    A-{{ $absentCount }}
                                    L-{{ $leaveCount }}
                                    Date: {{ $attendance['student_id'] }} |
                                        Attendance: {{ $attendance['is_present'] ? 'Present' : 'Absent' }}
                                </td> --}}
                                <td class="edit ">
                                    {{ $data->std_att_created_at }}
                                </td>
                                <td class="edit ">
                                    {{ $user->user_name }}
                                </td>
                            </tr>
                            @php
                                $sr++;
                                !empty($segmentSr) && $countSeg !== '0' ?: $countSeg++;
                            @endphp
                            @empty
                                <tr>
                                    <td colspan="11">
                                        <center>
                                            <h3 style="color:#554F4F">No Class</h3>
                                        </center>
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
                <div class="row">
                    <div class="col-md-3">
                        <span>Showing {{ $datas->firstItem() }} - {{ $datas->lastItem() }} of {{ $datas->total() }}</span>
                    </div>
                    <div class="col-md-9 text-right">
                        <span
                            class="hide_column">{{ $datas->appends(['segmentSr' => $countSeg, 'search' => $search])->links() }}</span>
                    </div>
                </div>
            </div> <!-- white column form ends here -->
        </div><!-- row end -->

        <!-- Modal -->
        <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog modal-lg">
                <div class="modal-content base_clr">
                    <div class="modal-header">
                        <h4 class="modal-title text-black">Student Attedance List</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">

                        <div id="table_body">

                        </div>
                        <div id="hello"></div>

                    </div>

                    <div class="modal-footer">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div class="form_controls">
                                <button type="button" class="btn btn-default form-control cancel_button"
                                    data-dismiss="modal">
                                    <i class="fa fa-times"></i> Cancel
                                </button>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    @endsection

    @section('scripts')
        {{--    add code by shahzaib start --}}
        <script type="text/javascript">
            var base = '{{ route('student_attendance_list') }}',
                url;

            @include('include.print_script_sh')
        </script>
        <script>
            $(document).ready(function() {
                $('[data-toggle="tooltip"]').tooltip();
            });
        </script>
        {{--    add code by shahzaib end --}}

        <script>
            $(document).ready(function() {
                $('.enable_disable').change(function() {
                    let status = $(this).prop('checked') === true ? 0 : 1;
                    let regId = $(this).data('id');
                    $.ajax({
                        type: "GET",
                        dataType: "json",
                        url: '{{ route('enable_disable_region') }}',
                        data: {
                            'status': status,
                            'regId': regId
                        },
                        success: function(data) {
                            console.log(data.message);
                        }
                    });
                });
            });
            jQuery("#search").select2();
        </script>
        <script>
            jQuery("#cancel").click(function() {
                $("#search").val('');
                $("#date").val('');
            });
        </script>

        <script>
            jQuery(".edit").click(function() {

                var std_att_id = jQuery(this).parent('tr').attr("data-std_att_id");
                var student_id = jQuery(this).parent('tr').attr("data-student_id");
                var class_id = jQuery(this).parent('tr').attr("data-class_id");
                jQuery("#title").val(std_att_id);
                jQuery("#class_degree_id").val(student_id);
                // jQuery("#class_incharge_id").val(class_incharge_id);
                jQuery("#class_id").val(class_id);
                jQuery("#edit").submit();
            });

            $('.delete').on('click', function(event) {

                var class_id = jQuery(this).attr("data-class_id");

                event.preventDefault();
                Swal.fire({
                    title: 'Are you sure?',
                    icon: 'warning',
                    showCancelButton: true,
                    cancelButtonColor: '#d33',
                    confirmButtonColor: '#3085d6',
                    confirmButtonText: 'Yes',
                }).then(function(result) {

                    if (result.value) {
                        jQuery("#class_id").val(class_id);
                        jQuery("#delete").submit();
                    } else {

                    }
                });
            });
        </script>
        <script>
            // jQuery("#invoice_no").blur(function () {
            jQuery(".view").click(function() {

                // jQuery(".pre-loader").fadeToggle("medium");
                jQuery("#table_body").html("");

                var class_id = jQuery(this).attr("data-class_id");
                var cs_id = jQuery(this).attr("data-cs_id");
                var date = jQuery(this).attr("data-std_att_created_at")
                $(".modal-body").load('{{ url('class_attendance_view_detail/view/') }}/' + class_id + '/' +
                cs_id + '/' + date,
                    function() {
                        // jQuery(".pre-loader").fadeToggle("medium");
                        $("#myModal").modal({
                            show: true
                        });
                    });
            });
              jQuery.ajaxSetup({ 
           headers: { 
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content') 
            } 
         }); 
 
        </script>


    @endsection
